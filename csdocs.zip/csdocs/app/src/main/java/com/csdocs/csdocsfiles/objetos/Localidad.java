package com.csdocs.csdocsfiles.objetos;

import java.io.Serializable;

public class Localidad implements Serializable {
    String id;
    String municipality;
    String locality;
    String state;

    public Localidad() {

    }

    public Localidad(String id, String municipality, String locality, String state) {
        this.id = id;
        this.municipality = municipality;
        this.locality = locality;
        this.state = state;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMunicipality() {
        return municipality;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return  locality;
    }
}
