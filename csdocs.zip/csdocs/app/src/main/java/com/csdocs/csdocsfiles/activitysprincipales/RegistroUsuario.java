package com.csdocs.csdocsfiles.activitysprincipales;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bringsolutions.csdocsfiles.R;
import com.csdocs.csdocsfiles.objetos.*;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


public class RegistroUsuario extends AppCompatActivity {
    EditText cajaNombre, cajaApPaterno, cajaApMaterno, cajaRFC, cajaCURP, cajaTipoUsuario, cajaTelefono, cajaLocalidad, cajaCalle, cajaCP, cajaEstatusUsuario, cajaCorreoElectronico, cajaPassword, cajaRepetirPassword;
    EditText cajaEstado, cajaMunicipio;
    Button btnRegistrarse;
    Spinner spnGeneros, spnLocalidades;

    private RequestQueue requestQueue;
    boolean respuestaVerificacionRFC = false;
    boolean respuestaVerificarCURP = false;

    private List<Localidad> listaLocalidades = new ArrayList<>();
    String localidadSeleccionada = "";


    private TextInputLayout inputPass, inputCURP, inputEmail;
    AlertDialog dialogoRequisitosPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuario);
        inicializarElementos();
        clicks();
        obtenerLocalidad();
        validarRFC();
        validarCURP();
        validarIngresoPass(cajaPassword);
        validarIngresoEmail(cajaCorreoElectronico);
    }

    private void validarIngresoEmail(final EditText cajaCorreoElectronico) {
        cajaCorreoElectronico.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String re = cajaCorreoElectronico.getText().toString();

                if (re.contains("@")) {
                    //CREO MI ARREGLO ESTADOS DE ACCIONES
                    int[][] states = new int[][]{
                            new int[]{android.R.attr.state_enabled}, // enabled
                            new int[]{-android.R.attr.state_selected}, // disabled
                            new int[]{-android.R.attr.state_checked}, // unchecked
                            new int[]{android.R.attr.state_pressed}  // pressed
                    };

                    //CREO MI ARREGLO DE COLORES
                    int[] colors = new int[]{
                            Color.parseColor("#00DA28"),
                            Color.GREEN,
                            Color.GREEN,
                            Color.GREEN
                    };

                    //CREO OBJETO DE LISTA DE COLORES Y LE PASO MIS ARREGLOS
                    ColorStateList myList = new ColorStateList(states, colors);
                    inputEmail.setHelperText("¡Correo electrónico válido!");
                    inputEmail.setHelperTextColor(myList);

                } else {
                    inputEmail.setHelperText(null);

                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    private void validarIngresoPass(final EditText cajaPass) {
        cajaPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String re = cajaPass.getText().toString();

                if (re.matches("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}") == false) {
                    inputPass.setError("Requisitos: " + "\nOcho o más caracteres \nCombinar letras mayúsculas y minúsculas \nIncluir números \nUtilizar símbolos de teclado ($ % & € # () [] @)");
                } else {
                    inputPass.setError("");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void validarCURP() {
        cajaCURP.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                verificarCURP(cajaCURP.getText().toString());


            }
        });
    }

    private void verificarCURP(String curp) {
        String regex =
                "[A-Z]{1}[AEIOU]{1}[A-Z]{2}[0-9]{2}" +
                        "(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])" +
                        "[HM]{1}" +
                        "(AS|BC|BS|CC|CS|CH|CL|CM|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS|NE)" +
                        "[B-DF-HJ-NP-TV-Z]{3}" +
                        "[0-9A-Z]{1}[0-9]{1}$";
        Pattern patron = Pattern.compile(regex);
        if (!patron.matcher(curp).matches()) {
            inputCURP.setHelperText(null);

            respuestaVerificarCURP = false;

        } else {
            //CREO MI ARREGLO ESTADOS DE ACCIONES
            int[][] states = new int[][]{
                    new int[]{android.R.attr.state_enabled}, // enabled
                    new int[]{-android.R.attr.state_selected}, // disabled
                    new int[]{-android.R.attr.state_checked}, // unchecked
                    new int[]{android.R.attr.state_pressed}  // pressed
            };

            //CREO MI ARREGLO DE COLORES
            int[] colors = new int[]{
                    Color.parseColor("#00DA28"),
                    Color.GREEN,
                    Color.GREEN,
                    Color.GREEN
            };

            //CREO OBJETO DE LISTA DE COLORES Y LE PASO MIS ARREGLOS
            ColorStateList myList = new ColorStateList(states, colors);
            inputCURP.setHelperText("¡CURP verificada!");
            inputCURP.setHelperTextColor(myList);

            respuestaVerificarCURP = true;
        }
    }

    private void validarRFC() {
        cajaRFC.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                verificaRFC(cajaRFC.getText().toString());
            }
        });
    }

    private void verificaRFC(String rfc) {
        if (rfc.length() > 12) {
            try {
                JSONObject postparams = new JSONObject();
                postparams.put("rfc", rfc);

                String url = Constantes.urlPrincipal + "eFirmas/public/api/rfc/";

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url + rfc, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                System.out.println(response);
                                Toast.makeText(RegistroUsuario.this, "" + response, Toast.LENGTH_LONG).show();
                                respuestaVerificacionRFC = true;
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(RegistroUsuario.this, "El rfc no existe [" + error.toString() + "]", Toast.LENGTH_LONG).show();
                                respuestaVerificacionRFC = false;
                            }
                        }
                ) {
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Content-Type", "application/json");

                        return headers;
                    }

                };
                requestQueue.add(jsonObjectRequest);

            } catch (Exception e) {

            }
        }
    }

    private void clicks() {

        btnRegistrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final PrepararRegistro preRegistro = new PrepararRegistro(cajaNombre.getText().toString(), cajaApPaterno.getText().toString(), cajaApMaterno.getText().toString(),
                        cajaRFC.getText().toString(), cajaCURP.getText().toString(), "1" /* cajaTipoUsuario.getText().toString() */, obtenerGenero(), cajaTelefono.getText().toString(),
                        /* cajaLocalidad.getText().toString()*/ obtenerLocalidadSeleccionada(spnLocalidades), cajaCP.getText().toString(), "3" /* cajaEstatusUsuario.getText().toString() */, cajaCorreoElectronico.getText().toString(), cajaPassword.getText().toString(),
                        cajaRepetirPassword.getText().toString(), cajaCalle.getText().toString());

                if (preRegistro.getCajaPassword().equals("1")) {
                    dialogoRequisitosPass();
                    Toast.makeText(RegistroUsuario.this, "Las contraseñas ingresadas no coinciden.", Toast.LENGTH_SHORT).show();
                } else if (preRegistro.getCajaPassword().equals("2")) {
                    dialogoRequisitosPass();
                    Toast.makeText(RegistroUsuario.this, "No se ha ingresado contraseña.", Toast.LENGTH_SHORT).show();
                } else if (preRegistro.getCajaPassword().equals("3")) {
                    dialogoRequisitosPass();
                    Toast.makeText(RegistroUsuario.this, "La contraseña es menor a ocho caracteres.", Toast.LENGTH_SHORT).show();
                } else if (preRegistro.getCajaPassword().equals("4")) {
                    dialogoRequisitosPass();
                    Toast.makeText(RegistroUsuario.this, "La contraseña no cumple los requisitos.", Toast.LENGTH_SHORT).show();
                } else if (preRegistro.getCajaTipoGenero().equals("")) {
                    Toast.makeText(RegistroUsuario.this, "Seleccione un género", Toast.LENGTH_SHORT).show();
                } else {
                    realizarRegistroBD(preRegistro);
                }


             /*   if (validarCampos()) {

                } else {
                    Toast.makeText(RegistroUsuario.this, "Algún campo vacío.", Toast.LENGTH_SHORT).show();
                }*/
            }
        });


    }

    private void dialogoRequisitosPass() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RegistroUsuario.this);
        alertDialogBuilder.setMessage("Requisitos: " + "\nOcho o más caracteres \nCombinar letras mayúsculas y minúsculas \nIncluir números \nUtilizar símbolos de teclado ($ % & € # () [] @)");
        alertDialogBuilder.setTitle("Verifique su contraseña");
        alertDialogBuilder.setPositiveButton("ENTENDIDO",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        dialogoRequisitosPass.dismiss();
                    }
                });

        dialogoRequisitosPass = alertDialogBuilder.create();
        dialogoRequisitosPass.show();

    }

    private void obtenerLocalidad() {
        cajaCP.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                obtenerDatosUbicacion(cajaCP.getText().toString());


            }
        });
    }


    private void obtenerDatosUbicacion(String cp) {
        listaLocalidades.clear();
        listaLocalidades.add(new Localidad("", "", "Seleccione una localidad:", ""));

        if (cp.length() > 4) {
            try {
                JSONObject postparams = new JSONObject();
                postparams.put("zipCode", cp);
                String url = Constantes.urlPrincipal + "eFirmas/public/addresses/getLocalitiesByCP/";

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url + cp, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                JSONObject jo = null;
                                try {
                                    Toast.makeText(RegistroUsuario.this, "¡CP validado!", Toast.LENGTH_LONG).show();
                                    JSONArray rArray = response.getJSONArray("localities");
                                    for (int i = 0; i < rArray.length(); i++) {
                                        jo = rArray.getJSONObject(i);
                                        //POBLO UNA LISTA CON TODAS LAS LOCALIDADES
                                        listaLocalidades.add(new Localidad(jo.getString("id"), jo.getString("municipality"), jo.getString("locality"), jo.getString("state")));
                                    }

                                    for (int j = 1; j < listaLocalidades.size(); j++) {
                                        System.out.println("DATOOSS: " + listaLocalidades.get(j).getState());
                                    }


                                } catch (Exception e) {

                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(RegistroUsuario.this, "Teclee de nuevo su Código Postal [" + error.toString() + "]", Toast.LENGTH_LONG).show();
                            }
                        }
                ) {
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Content-Type", "application/json");
                        return headers;
                    }
                };
                requestQueue.add(jsonObjectRequest);


            } catch (Exception e) {
            }
        }

        ArrayAdapter<Localidad> adapter = new ArrayAdapter<>(RegistroUsuario.this, android.R.layout.simple_spinner_item, listaLocalidades);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spnLocalidades.setAdapter(adapter);
    }


    private String obtenerGenero() {
        if (spnGeneros.getSelectedItemPosition() == 1) {
            return "1"; //Masculino
        } else if (spnGeneros.getSelectedItemPosition() == 2) {
            return "2"; //Femenino
        }
        return "";
    }

    private void realizarRegistroBD(PrepararRegistro preRegistro) {
        try {
            JSONObject postparams = new JSONObject();
            postparams.put("user_name", preRegistro.getCajaNombre());
            postparams.put("last_name", preRegistro.getCajaApPaterno());
            postparams.put("second_last_name", preRegistro.getCajaApMaterno());
            postparams.put("rfc", preRegistro.getCajaRFC());
            postparams.put("curp", preRegistro.getCajaCURP());
            postparams.put("user_type", preRegistro.getCajaTipoUsuario()); //aquí se le manda 1 por default (donde poblo el objeto preRegistro)
            postparams.put("genders", preRegistro.getCajaTipoGenero());
            postparams.put("telephone", preRegistro.getCajaTelefono());
            postparams.put("fk_localities", preRegistro.getCajaLocalidad());
            postparams.put("fk_user_status", preRegistro.getCajaEstatusUsuario()); //aquí se le manda 1 por default (donde poblo el objeto preRegistro)
            postparams.put("email", preRegistro.getCajaCorreoElectronico());
            postparams.put("password", preRegistro.getCajaPassword());
            postparams.put("address", preRegistro.getCajaCalle());

            String url = Constantes.urlPrincipal + "eFirmas/public/createUser";

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postparams,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            findViewById(R.id.lnLottieRegistro).setVisibility(View.VISIBLE);
                            new CountDownTimer(1800, 1000) {

                                public void onTick(long millisUntilFinished) {
                                }

                                public void onFinish() {
                                    findViewById(R.id.lnLottieRegistro).setVisibility(View.GONE);
                                }
                            }.start();
                            Toast.makeText(RegistroUsuario.this, "El usuario se ha registrado correctamente", Toast.LENGTH_LONG).show();
                            finish();
                            startActivity(new Intent(RegistroUsuario.this, Login.class));
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(RegistroUsuario.this, "Se produjo un problema al registrar el usuario: [" + error.toString() + "]", Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Content-Type", "application/json");

                    return headers;
                }

            };
            requestQueue.add(jsonObjectRequest);

        } catch (Exception e) {
        }
    }

    private boolean validarCampos() {
        return cajaNombre.getText().toString().isEmpty() || cajaApPaterno.getText().toString().isEmpty() || cajaApMaterno.getText().toString().isEmpty() ||
                cajaRFC.getText().toString().isEmpty() || cajaCURP.getText().toString().isEmpty() ||
                cajaTipoUsuario.getText().toString().isEmpty() || cajaTelefono.getText().toString().isEmpty() || spnLocalidades.getSelectedItemPosition() != 0 ? false : true || cajaCalle.getText().toString().isEmpty() || cajaCP.getText().toString().isEmpty()
                || cajaEstatusUsuario.getText().toString().isEmpty() || cajaCorreoElectronico.getText().toString().isEmpty() || cajaPassword.getText().toString().isEmpty() || cajaRepetirPassword.getText().toString().isEmpty() || cajaCalle.getText().toString().isEmpty() ? false : true;
    }


    private void inicializarElementos() {
        requestQueue = Volley.newRequestQueue(RegistroUsuario.this);
        cajaNombre = findViewById(R.id.cajaNombre);
        cajaApPaterno = findViewById(R.id.cajaApellidoPaterno);
        cajaApMaterno = findViewById(R.id.cajaApellidoMaterno);
        cajaRFC = findViewById(R.id.cajaRFC);
        cajaCURP = findViewById(R.id.cajaCURP);
        cajaTipoUsuario = findViewById(R.id.cajaTipoUsuario);
        cajaTelefono = findViewById(R.id.cajaTelefono);
        cajaLocalidad = findViewById(R.id.cajaLocalidad);
        cajaCalle = findViewById(R.id.cajaCalle);
        cajaCP = findViewById(R.id.cajaCP);
        cajaEstatusUsuario = findViewById(R.id.cajaEstatusUsuario);
        cajaCorreoElectronico = findViewById(R.id.cajaCorreoElectronico);
        cajaPassword = findViewById(R.id.cajaPassword);
        btnRegistrarse = findViewById(R.id.btnRegistrarse);
        cajaRepetirPassword = findViewById(R.id.cajaRepetirPassword);
        spnGeneros = findViewById(R.id.spnGeneros);
        cajaEstado = findViewById(R.id.cajaEstado);
        cajaMunicipio = findViewById(R.id.cajaMunicipio);
        spnLocalidades = findViewById(R.id.spnLocalidades);
        obtenerLocalidadSeleccionada(spnLocalidades);
        inputPass = findViewById(R.id.inputPass);
        inputCURP = findViewById(R.id.inputCURP);
        inputEmail = findViewById(R.id.inputEmail);

    }

    public String obtenerLocalidadSeleccionada(final Spinner spnLocalidades) {
        spnLocalidades.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                try {
                    int numLocalidadSeleccionada = spnLocalidades.getSelectedItemPosition();
                    if (numLocalidadSeleccionada != 0) {
                        Localidad localidad = (Localidad) spnLocalidades.getItemAtPosition(numLocalidadSeleccionada);
                        localidadSeleccionada = localidad.getId();
                        cajaMunicipio.setText(localidad.getMunicipality());
                        cajaLocalidad.setText(localidad.getLocality());
                        cajaEstado.setText(localidad.getState());
                    }
                } catch (Exception e) {
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
        return localidadSeleccionada;
    }


}