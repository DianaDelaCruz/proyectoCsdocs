package com.csdocs.csdocsfiles.ui.descargaconstancia;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bringsolutions.csdocsfiles.R;

public class DescargaConstanciaFragment extends Fragment {
    View view;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_descarga_constancia, container, false);

        return view;
    }
}