package com.csdocs.csdocsfiles;

import android.content.Intent;
import android.os.Bundle;

import com.android.volley.RequestQueue;
import com.csdocs.csdocsfiles.activitysprincipales.Login;
import com.csdocs.csdocsfiles.objetos.Constantes;

import com.bringsolutions.csdocsfiles.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.MenuItem;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView tvNombreUsuario;
    private RequestQueue requestQueue;

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        View hView = navigationView.getHeaderView(0);
        tvNombreUsuario = hView.findViewById(R.id.tvNombreUsuarioLogin);
        try {
            tvNombreUsuario.setText(Constantes.usuarioLogin.getUser_name() + " " + Constantes.usuarioLogin.getSecond_last_name() + " " + Constantes.usuarioLogin.getLast_name());
        } catch (Exception e) {

        }


        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.registro_usuario,
                R.id.carga_documentos, R.id.firma_electronica, R.id.descarga_constancia,
                R.id.contacto, R.id.preguntas_frecuentes)
                .setDrawerLayout(drawer)
                .build();


        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        Menu menuPrincipal = navigationView.getMenu();
        MenuItem registroUsuario = menuPrincipal.findItem(R.id.registro_usuario);
        MenuItem cargaDocumentos = menuPrincipal.findItem(R.id.carga_documentos);
        MenuItem firmaElectronica = menuPrincipal.findItem(R.id.firma_electronica);

        if (Constantes.tipoUsuario == 1) {
            //ADMNISTRADOR
            registroUsuario.setTitle("Registrar Usuario");
        } else if (Constantes.tipoUsuario == 2) {
            //USUARIO NORMAL
            registroUsuario.setTitle("Mis Datos");
            registroUsuario.setIcon(R.drawable.ic_mis_datos);
            cargaDocumentos.setVisible(false);
            firmaElectronica.setVisible(false);

        }

        MenuItem salir = menuPrincipal.findItem(R.id.cerrar_sesion);
        salir.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                startActivity(new Intent(MainActivity.this, Login.class));
                finish();
                return false;
            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
