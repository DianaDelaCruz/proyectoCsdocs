package com.csdocs.csdocsfiles.activitysprincipales;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bringsolutions.csdocsfiles.R;

import com.csdocs.csdocsfiles.MainActivity;
import com.csdocs.csdocsfiles.objetos.Constantes;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    //Datos Volley
    private RequestQueue requestQueue;
    private EditText cajaEmail;
    private EditText cajaPass;
    private Button btnIniciarSesion;
    private TextView tvSaludo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inicializarElementos();

        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    findViewById(R.id.lnLottieLogin).setVisibility(View.VISIBLE);
                    verificar(cajaEmail.getText().toString(), cajaPass.getText().toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    private void verificar(String email, String password) throws JSONException {
        JSONObject postparams = new JSONObject();
        postparams.put("email", email);
        postparams.put("password", password);

        String url = Constantes.urlPrincipal + "eFirmas/public/login";
        System.out.println("detalle: " + url );

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, postparams,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject jUser = response.getJSONObject("user");
                            Constantes.usuarioLogin.setId(jUser.getString("id"));
                            Constantes.usuarioLogin.setUser_name(jUser.getString("user_name"));
                            Constantes.usuarioLogin.setLast_name(jUser.getString("last_name"));
                            Constantes.usuarioLogin.setSecond_last_name(jUser.getString("second_last_name"));
                            Constantes.usuarioLogin.setRfc(jUser.getString("rfc"));
                            Constantes.usuarioLogin.setCurp(jUser.getString("curp"));
                            Constantes.usuarioLogin.setEmail(jUser.getString("email"));
                            Constantes.usuarioLogin.setUser_type(jUser.getString("user_type"));
                            Constantes.usuarioLogin.setGenders(jUser.getString("genders"));
                            Constantes.usuarioLogin.setKeycer(jUser.getString("keycer"));
                            Constantes.usuarioLogin.setKeyprivate(jUser.getString("keyprivate"));
                            Constantes.usuarioLogin.setKeypublic(jUser.getString("keypublic"));
                            Constantes.usuarioLogin.setRemember_token(jUser.getString("remember_token"));
                            Constantes.usuarioLogin.setApi_token(jUser.getString("api_token"));
                            Constantes.usuarioLogin.setTelephone(jUser.getString("telephone"));
                            Constantes.usuarioLogin.setFk_localities(jUser.getString("fk_localities"));
                            Constantes.usuarioLogin.setAddress(jUser.getString("address"));
                            Constantes.usuarioLogin.setFk_user_status(jUser.getString("fk_user_status"));
                            Constantes.usuarioLogin.setCreated_at(jUser.getString("created_at"));
                            Constantes.usuarioLogin.setUpdated_at(jUser.getString("updated_at"));

                        } catch (Exception e) {

                        }

                        Toast.makeText(Login.this, "¡Bienvenido!", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(Login.this, MainActivity.class));
                        findViewById(R.id.lnLottieLogin).setVisibility(View.GONE);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        findViewById(R.id.lnLottieLogin).setVisibility(View.GONE);
                        System.out.println("detalle: " + error.toString() );
                        Toast.makeText(Login.this, "Se produjo un problema a la hora de iniciar sesión.", Toast.LENGTH_LONG).show();
                       // startActivity(new Intent(Login.this, MainActivity.class));
                        System.out.println("el problema es : "+ error);
                        Toast.makeText(Login.this, "El problema es " +error, Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                

                return headers;
            }

        };
        requestQueue.add(jsonObjectRequest);
    }


    private void inicializarElementos() {
        cajaEmail = findViewById(R.id.cajaEmail);
        cajaPass = findViewById(R.id.cajaPass);
        btnIniciarSesion = findViewById(R.id.btnIniciarSesion);
        requestQueue = Volley.newRequestQueue(Login.this);
        tvSaludo = findViewById(R.id.tvSaludo);
        saludoDelDia(tvSaludo);
    }

    public static void saludoDelDia(TextView tvSaludo) {
        Calendar calendario = Calendar.getInstance();
        int horaDia = calendario.get(Calendar.HOUR_OF_DAY);
        if (horaDia >= 0 && horaDia < 12) {
            tvSaludo.setText("Buenos días!");
        } else if (horaDia >= 12 && horaDia < 15) {
            tvSaludo.setText("Buenas tardes!");
        } else if (horaDia >= 15 && horaDia < 19) {
            tvSaludo.setText("Buenas tardes!");
        } else if (horaDia >= 19 && horaDia < 24) {
            tvSaludo.setText("Buenas noches!");
        }
    }


    public void irRegistroUsuario(View view) {
        startActivity(new Intent(Login.this, RegistroUsuario.class));
    }
}
