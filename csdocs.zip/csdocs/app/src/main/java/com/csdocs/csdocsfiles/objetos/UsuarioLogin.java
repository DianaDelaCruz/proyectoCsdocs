package com.csdocs.csdocsfiles.objetos;

import java.io.Serializable;

public class UsuarioLogin implements Serializable {
    private String id;
    private String user_name;
    private String last_name;
    private String second_last_name;
    private String rfc;
    private String curp;
    private String email;
    private String user_type;
    private String genders;
    private String keycer;
    private String keyprivate;
    private String keypublic;
    private String remember_token;
    private String api_token;
    private String telephone;

    private String fk_localities;
    private String address;
    private String fk_user_status;
    private String created_at;
    private String updated_at;

    public UsuarioLogin() {

    }

    public UsuarioLogin(String id, String user_name, String last_name, String second_last_name, String rfc, String curp, String email, String user_type, String genders, String keycer, String keyprivate, String keypublic, String remember_token, String api_token, String telephone, String fk_localities, String address, String fk_user_status, String created_at, String updated_at) {
        this.id = id;
        this.user_name = user_name;
        this.last_name = last_name;
        this.second_last_name = second_last_name;
        this.rfc = rfc;
        this.curp = curp;
        this.email = email;
        this.user_type = user_type;
        this.genders = genders;
        this.keycer = keycer;
        this.keyprivate = keyprivate;
        this.keypublic = keypublic;
        this.remember_token = remember_token;
        this.api_token = api_token;
        this.telephone = telephone;
        this.fk_localities = fk_localities;
        this.address = address;
        this.fk_user_status = fk_user_status;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getSecond_last_name() {
        return second_last_name;
    }

    public void setSecond_last_name(String second_last_name) {
        this.second_last_name = second_last_name;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getGenders() {
        return genders;
    }

    public void setGenders(String genders) {
        this.genders = genders;
    }

    public String getKeycer() {
        return keycer;
    }

    public void setKeycer(String keycer) {
        this.keycer = keycer;
    }

    public String getKeyprivate() {
        return keyprivate;
    }

    public void setKeyprivate(String keyprivate) {
        this.keyprivate = keyprivate;
    }

    public String getKeypublic() {
        return keypublic;
    }

    public void setKeypublic(String keypublic) {
        this.keypublic = keypublic;
    }

    public String getRemember_token() {
        return remember_token;
    }

    public void setRemember_token(String remember_token) {
        this.remember_token = remember_token;
    }

    public String getApi_token() {
        return api_token;
    }

    public void setApi_token(String api_token) {
        this.api_token = api_token;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getFk_localities() {
        return fk_localities;
    }

    public void setFk_localities(String fk_localities) {
        this.fk_localities = fk_localities;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFk_user_status() {
        return fk_user_status;
    }

    public void setFk_user_status(String fk_user_status) {
        this.fk_user_status = fk_user_status;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    @Override
    public String toString() {
        return "UsuarioLogin{" +
                "id='" + id + '\'' +
                ", user_name='" + user_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", second_last_name='" + second_last_name + '\'' +
                ", rfc='" + rfc + '\'' +
                ", curp='" + curp + '\'' +
                ", email='" + email + '\'' +
                ", user_type='" + user_type + '\'' +
                ", genders='" + genders + '\'' +
                ", keycer='" + keycer + '\'' +
                ", keyprivate='" + keyprivate + '\'' +
                ", keypublic='" + keypublic + '\'' +
                ", remember_token='" + remember_token + '\'' +
                ", api_token='" + api_token + '\'' +
                ", telephone='" + telephone + '\'' +
                ", fk_localities='" + fk_localities + '\'' +
                ", address='" + address + '\'' +
                ", fk_user_status='" + fk_user_status + '\'' +
                ", created_at='" + created_at + '\'' +
                ", updated_at='" + updated_at + '\'' +
                '}';
    }
}
