package com.csdocs.csdocsfiles.objetos;

import java.sql.Timestamp;

public class Document
{
    private Integer id;
    private String name;
    private String srcDocument;
    private String statusDocuments;
    private String validity;
    private User fkUsers;
    private DocumentType fkDocumentsType;
    private Timestamp createdAt;
    private Timestamp updatedAt;


    public Document(String name, String srcDocument)
    {
        this.name = name;
        this.srcDocument = srcDocument;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getSrcDocument()
    {
        return srcDocument;
    }

    public void setSrcDocument(String srcDocument)
    {
        this.srcDocument = srcDocument;
    }

    public String getStatusDocuments()
    {
        return statusDocuments;
    }

    public void setStatusDocuments(String statusDocuments)
    {
        this.statusDocuments = statusDocuments;
    }

    public String getValidity()
    {
        return validity;
    }

    public void setValidity(String validity)
    {
        this.validity = validity;
    }

    public User getFkUsers()
    {
        return fkUsers;
    }

    public void setFkUsers(User fkUsers)
    {
        this.fkUsers = fkUsers;
    }

    public DocumentType getFkDocumentsType()
    {
        return fkDocumentsType;
    }

    public void setFkDocumentsType(DocumentType fkDocumentsType)
    {
        this.fkDocumentsType = fkDocumentsType;
    }

    public Timestamp getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt)
    {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt()
    {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt)
    {
        this.updatedAt = updatedAt;
    }
}
