package com.csdocs.csdocsfiles.objetos;

public class Constantes {
    public static String urlPrincipal = "http://10.1.1.35/";
    public static int tipoUsuario = 1;

    public static UsuarioLogin usuarioLogin = new UsuarioLogin();
}
