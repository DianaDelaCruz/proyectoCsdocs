package com.csdocs.csdocsfiles.ui.registrousuario;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bringsolutions.csdocsfiles.R;
import com.csdocs.csdocsfiles.objetos.Constantes;

public class RegistroUsuarioFragment extends Fragment {
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_registro_usuario, container, false);
        if (Constantes.tipoUsuario == 1) {
            //ADMNISTRADOR
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Registrar Usuario");
        } else if (Constantes.tipoUsuario == 2) {
            //USUARIO NORMAL
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Mis Datos");

        }

        return view;
    }
}
