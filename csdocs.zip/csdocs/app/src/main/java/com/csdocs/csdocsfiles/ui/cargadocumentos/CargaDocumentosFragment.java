package com.csdocs.csdocsfiles.ui.cargadocumentos;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.bringsolutions.csdocsfiles.BuildConfig;
import com.bringsolutions.csdocsfiles.R;
import com.csdocs.csdocsfiles.objetos.RealPathUtil;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadNotificationConfig;
import net.gotev.uploadservice.UploadStatusDelegate;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;

public class CargaDocumentosFragment extends Fragment {
    int casoTipoFotoSeleccion;
    static final int SOLICITUD_ARCHIVO = 10;
    private Uri uriArchivo;
    private File fotoArchivo;
    View view;
    Button boton , btnActaNacimiento,btnCurp,btnIne,btnComprobanteDomicilio;
    EditText txtActaNacimiento,txtCurp,txtIne,txtComprobante;

    String Servidor = "eFirmas/public/obtenerFirma";
    ProgressDialog progressDialog;
    String urlArchivoFinal = null;
    int archivo =0;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_carga_documentos, container, false);
        inicializarElementos();

        clicks();
        return view;
    }

    private void clicks() {
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              /*  if (txtActaNacimiento.getText().toString().isEmpty()||txtComprobante.getText().toString().isEmpty()||txtIne.getText().toString().isEmpty()||txtCurp.getText().toString().isEmpty())
                {
                    Toast.makeText(getContext(), "Favor de seleccionar todos los documentos ", Toast.LENGTH_SHORT).show();
                }else {
                    ArrayList<Document> documentos = new ArrayList();
                    documentos.add(new Document("ActaNacimiento",txtActaNacimiento.getText().toString()));
                    documentos.add(new Document("Curp",txtCurp.getText().toString()));
                    documentos.add(new Document("Ine",txtIne.getText().toString()));
                    documentos.add(new Document("ComporbanteDomicilio",txtComprobante.getText().toString()));

                    for (int i = 0; i <documentos.size() ; i++)
                    {
                        subirArchivoServidor(documentos.get(i).getSrcDocument(),documentos.get(i).getName());
                    }
                }
*/

/**
 * Creating Document
 */
                com.itextpdf.text.Document document= new Document();
// Location to save
                try
                {
                    // Se crea el documento
                    Document documento = new Document();

// Se crea el OutputStream para el fichero donde queremos dejar el pdf.
                    FileOutputStream ficheroPdf = new FileOutputStream("fichero.pdf");

// Se asocia el documento al OutputStream y se indica que el espaciado entre
// lineas sera de 20. Esta llamada debe hacerse antes de abrir el documento
                    PdfWriter.getInstance(documento,ficheroPdf).setInitialLeading(20);

// Se abre el documento.
                    documento.open();

                    documento.add(new Paragraph("Esto es el primer párrafo, normalito"));

                    documento.add(new Paragraph("Este es el segundo y tiene una fuente rara",
                            FontFactory.getFont("arial",   // fuente
                                    22,                            // tamaño
                                    Font.ITALIC,                   // estilo
                                    BaseColor.CYAN)));             // color

                    documento.add(new Paragraph("Esto es el primer párrafo, normalito"));

                    documento.add(new Paragraph("Este es el segundo y tiene una fuente rara",
                            FontFactory.getFont("arial",   // fuente
                                    22,                            // tamaño
                                    Font.ITALIC,                   // estilo
                                    BaseColor.CYAN)));             // color


                }catch (Exception we){

                }


// Open to write
                document.open();
            }
        });


        btnActaNacimiento.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                obtenerRuta();
                archivo = 1;
            }
        });

        btnCurp.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                obtenerRuta();
                archivo = 2;
            }
        });

        btnIne.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                obtenerRuta();
                archivo = 3;
            }
        });

        btnComprobanteDomicilio.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                obtenerRuta();
                archivo = 4;
            }
        });


    }

    private void mostrarRuta()
    {

        switch (archivo){
            case 1:
                txtActaNacimiento.setText(urlArchivoFinal);
                break;
            case 2:
                txtCurp.setText(urlArchivoFinal);
                break;
            case 3:
                txtIne.setText(urlArchivoFinal);
                break;
            case 4:
                txtComprobante.setText(urlArchivoFinal);
                break;
        }

    }
    private void obtenerRuta() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater layoutInflater = getLayoutInflater();
        final View viewDialog = layoutInflater.inflate(R.layout.dialog_tipo_evidencia, null);

        builder.setView(viewDialog);

        Button btnCancelar = viewDialog.findViewById(R.id.btnCancelarTipoEvidenciaFotografica);
        ImageView btnArchivos = viewDialog.findViewById(R.id.btnSeleccionarFotoOpcion);
        ImageView btnFotoCamara = viewDialog.findViewById(R.id.btnTomarFotoOpcion);

        final AlertDialog dialog = builder.create();

        btnArchivos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                casoTipoFotoSeleccion = 1;
                verificarPermisosCamaraMemoria(1);
                dialog.dismiss();

            }
        });

        btnFotoCamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                casoTipoFotoSeleccion = 2;
                verificarPermisosCamaraMemoria(2);
                dialog.dismiss();
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

            }
        });

        dialog.show();

    }

    //TIPO CASO 1: DESDE ARCHIVOS
//TIPO CASO 2: DESDE CÁMARA
    private void verificarPermisosCamaraMemoria(int tipoCaso) {
        if (getActivity() != null) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,}, 2);
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 3);
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 4);
            } else {
                validarEleccion(tipoCaso);
            }
        }

    }

    private void validarEleccion(int tipoCaso) {
        if (tipoCaso == 1) {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_LOCAL_ONLY, uriArchivo);
            startActivityForResult(Intent.createChooser(i, "Seleccione un archivo"), SOLICITUD_ARCHIVO);
        } else if (tipoCaso == 2) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
            String currentDateandTime = sdf.format(new Date());

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            fotoArchivo = new File(Environment.getExternalStorageDirectory(), "foto_seleccionada" + currentDateandTime + ".jpg");

            System.out.println("URL DE LA FOTO TOMADA " + fotoArchivo.getPath());
            if (getActivity() != null) {
                uriArchivo = FileProvider.getUriForFile(getActivity(), BuildConfig.APPLICATION_ID + ".fileprovider", fotoArchivo);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uriArchivo);
                startActivityForResult(intent, SOLICITUD_ARCHIVO);
            } else {
                Toast.makeText(getActivity(), "Ha ocurrido un error", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //1 = SELECCIÓN DE ARCHIVOS
        //2 = TOMAR FOTO DESDE LA CÁMARA

        if (requestCode == SOLICITUD_ARCHIVO && resultCode == RESULT_OK && casoTipoFotoSeleccion == 1) {
            try {

                if (RealPathUtil.getRealPath3(getContext(), data.getData()) == null) {
                    urlArchivoFinal = RealPathUtil.getPath2(getContext(), data.getData());
                } else if (RealPathUtil.getPath2(getContext(), data.getData()) == null) {
                    urlArchivoFinal = RealPathUtil.getPath(getContext(), data.getData());
                } else if (RealPathUtil.getPath(getContext(), data.getData()) == null) {
                    urlArchivoFinal = RealPathUtil.getRealPath3(getContext(), data.getData());
                }

              //  subirArchivoServidor(urlArchivoFinal, "archivoo_file");
                mostrarRuta();

            } catch (Exception e) {
                System.out.println("Excepción" + e.toString());
            }

        } else if (requestCode == SOLICITUD_ARCHIVO && resultCode == RESULT_OK && casoTipoFotoSeleccion == 2) {
            try {
                 urlArchivoFinal = fotoArchivo.getPath();
                //  subirArchivoServidor(urlArchivoFinal, "archivoo_file");
                mostrarRuta();

            } catch (Exception e) {
                System.out.println("Excepción" + e.toString());
            }

        }
    }



    private void subirArchivoServidor(String ruta, String nombre) {
        try {

            new MultipartUploadRequest(getActivity(), Servidor)
                    .addFileToUpload(ruta, "local")
                    .addParameter("filename",nombre)
                    .setNotificationConfig(new UploadNotificationConfig())
                    .setMaxRetries(5)
                    .setDelegate(new UploadStatusDelegate() {
                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {
                            double progress = (100.0 * uploadInfo.getUploadedBytes()) / uploadInfo.getTotalBytes();
                            double cargado = (uploadInfo.getUploadedBytes() / 1024);
                            double total = (uploadInfo.getTotalBytes() / 1024);
                            int cargaActual = (int) cargado;
                            progressDialog.setTitle("Subiendo tu archivo");
                            progressDialog.setMessage(((int) progress) + "% subido...");
                            progressDialog.setCancelable(false);
                            progressDialog.show();
                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {
                            System.out.println("respuesdelseerver" +serverResponse);
                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {
                            Toast.makeText(context, "Archivo subido!", Toast.LENGTH_SHORT).show();
                            view.findViewById(R.id.lnLottie).setVisibility(View.VISIBLE);
                            new CountDownTimer(1500, 1000) {

                                public void onTick(long millisUntilFinished) {
                                }

                                public void onFinish() {
                                    view.findViewById(R.id.lnLottie).setVisibility(View.GONE);
                                }
                            }.start();
                            progressDialog.hide();

                        }

                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {
                        }
                    }).startUpload();
        } catch (Exception exc) {
        }


    }


    private void inicializarElementos() {
        boton = view.findViewById(R.id.button);
        btnActaNacimiento = view.findViewById(R.id.buscar_acta);
        btnCurp=view.findViewById(R.id.buscar_curp);
        btnIne=view.findViewById(R.id.buscar_ine);
        btnComprobanteDomicilio= view.findViewById(R.id.buscar_comprobante);
        txtActaNacimiento = view.findViewById(R.id.nombre_acta);
        txtComprobante=view.findViewById(R.id.nombre_comprobante);
        txtIne=view.findViewById(R.id.nombre_ine);
        txtCurp=view.findViewById(R.id.nombre_curp);


        txtActaNacimiento.setEnabled(false);
        txtComprobante.setEnabled(false);
        txtCurp.setEnabled(false);
        txtIne.setEnabled(false);


        progressDialog = new ProgressDialog(getActivity());


    }

}