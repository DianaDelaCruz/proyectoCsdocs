package com.csdocs.csdocsfiles.objetos;


public class PrepararRegistro {
    private String cajaNombre, cajaApPaterno, cajaApMaterno, cajaRFC, cajaCURP, cajaTipoUsuario, cajaTipoGenero, cajaTelefono, cajaLocalidad, cajaCP, cajaEstatusUsuario, cajaCorreoElectronico, cajaPassword, cajaRepetirPassword, cajaCalle;

    public PrepararRegistro(String cajaNombre, String cajaApPaterno, String cajaApMaterno, String cajaRFC, String cajaCURP, String cajaTipoUsuario, String cajaTipoGenero, String cajaTelefono, String cajaLocalidad, String cajaCP, String cajaEstatusUsuario, String cajaCorreoElectronico, String cajaPassword, String cajaRepetirPassword, String cajaCalle) {
        this.cajaNombre = cajaNombre;
        this.cajaApPaterno = cajaApPaterno;
        this.cajaApMaterno = cajaApMaterno;
        this.cajaRFC = cajaRFC;
        this.cajaCURP = cajaCURP;
        this.cajaTipoUsuario = cajaTipoUsuario;
        this.cajaTipoGenero = cajaTipoGenero;
        this.cajaTelefono = cajaTelefono;
        this.cajaLocalidad = cajaLocalidad;
        this.cajaCP = cajaCP;
        this.cajaEstatusUsuario = cajaEstatusUsuario;
        this.cajaCorreoElectronico = cajaCorreoElectronico;
        this.cajaPassword = cajaPassword;
        this.cajaRepetirPassword = cajaRepetirPassword;
        this.cajaCalle = cajaCalle;
    }

    public String getCajaNombre() {
        return cajaNombre;
    }

    public void setCajaNombre(String cajaNombre) {
        this.cajaNombre = cajaNombre;
    }

    public String getCajaApPaterno() {
        return cajaApPaterno;
    }

    public void setCajaApPaterno(String cajaApPaterno) {
        this.cajaApPaterno = cajaApPaterno;
    }

    public String getCajaApMaterno() {
        return cajaApMaterno;
    }

    public void setCajaApMaterno(String cajaApMaterno) {
        this.cajaApMaterno = cajaApMaterno;
    }

    public String getCajaRFC() {
        return cajaRFC;
    }

    public void setCajaRFC(String cajaRFC) {
        this.cajaRFC = cajaRFC;
    }

    public String getCajaCURP() {
        return cajaCURP;
    }

    public void setCajaCURP(String cajaCURP) {
        this.cajaCURP = cajaCURP;
    }

    public String getCajaTipoUsuario() {
        return cajaTipoUsuario;
    }

    public void setCajaTipoUsuario(String cajaTipoUsuario) {
        this.cajaTipoUsuario = cajaTipoUsuario;
    }

    public String getCajaTipoGenero() {
        return cajaTipoGenero;
    }

    public void setCajaTipoGenero(String cajaTipoGenero) {
        this.cajaTipoGenero = cajaTipoGenero;
    }

    public String getCajaTelefono() {
        return cajaTelefono;
    }

    public void setCajaTelefono(String cajaTelefono) {
        this.cajaTelefono = cajaTelefono;
    }

    public String getCajaLocalidad() {
        return cajaLocalidad;
    }

    public void setCajaLocalidad(String cajaLocalidad) {
        this.cajaLocalidad = cajaLocalidad;
    }

    public String getCajaCP() {
        return cajaCP;
    }

    public void setCajaCP(String cajaCP) {
        this.cajaCP = cajaCP;
    }

    public String getCajaEstatusUsuario() {
        return cajaEstatusUsuario;
    }

    public void setCajaEstatusUsuario(String cajaEstatusUsuario) {
        this.cajaEstatusUsuario = cajaEstatusUsuario;
    }

    public String getCajaCorreoElectronico() {
        return cajaCorreoElectronico;
    }

    public void setCajaCorreoElectronico(String cajaCorreoElectronico) {
        this.cajaCorreoElectronico = cajaCorreoElectronico;
    }

    public String getCajaPassword() {
        String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";

        if (cajaPassword.equals(cajaRepetirPassword) == false) {
            return "1";
        } else if (cajaPassword.isEmpty() || cajaRepetirPassword.isEmpty()) {
            return "2";
        } else if (cajaPassword.length() < 8) {
            return "3";
        } else if (cajaPassword.matches(pattern) == false) {
            return "4";
        }
        return cajaPassword;
    }



    public void setCajaPassword(String cajaPassword) {
        this.cajaPassword = cajaPassword;
    }

    public String getCajaRepetirPassword() {
        return cajaRepetirPassword;
    }

    public void setCajaRepetirPassword(String cajaRepetirPassword) {
        this.cajaRepetirPassword = cajaRepetirPassword;
    }

    public String getCajaCalle() {
        return cajaCalle;
    }

    public void setCajaCalle(String cajaCalle) {
        this.cajaCalle = cajaCalle;
    }

    @Override
    public String toString() {
        return "PrepararRegistro{" +
                "cajaNombre='" + cajaNombre + '\'' +
                ", cajaApPaterno='" + cajaApPaterno + '\'' +
                ", cajaApMaterno='" + cajaApMaterno + '\'' +
                ", cajaRFC='" + cajaRFC + '\'' +
                ", cajaCURP='" + cajaCURP + '\'' +
                ", cajaTipoUsuario='" + cajaTipoUsuario + '\'' +
                ", cajaTipoGenero='" + cajaTipoGenero + '\'' +
                ", cajaTelefono='" + cajaTelefono + '\'' +
                ", cajaLocalidad='" + cajaLocalidad + '\'' +
                ", cajaCP='" + cajaCP + '\'' +
                ", cajaEstatusUsuario='" + cajaEstatusUsuario + '\'' +
                ", cajaCorreoElectronico='" + cajaCorreoElectronico + '\'' +
                ", cajaPassword='" + cajaPassword + '\'' +
                ", cajaRepetirPassword='" + cajaRepetirPassword + '\'' +
                ", cajaCalle='" + cajaCalle + '\'' +
                '}';
    }
}
